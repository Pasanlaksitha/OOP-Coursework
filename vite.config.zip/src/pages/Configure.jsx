import React from 'react';
import ConfigForm from '../components/ConfigForm';

const Configure = () => <ConfigForm />;

export default Configure;