import React from 'react';
import Simulation from '../components/Simulation';

const SimulationResults = () => <Simulation />;

export default SimulationResults;